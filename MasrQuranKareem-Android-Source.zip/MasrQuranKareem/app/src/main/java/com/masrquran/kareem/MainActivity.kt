package com.masrquran.kareem

import android.app.Activity
import android.app.DownloadManager
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.AdapterView
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity() {

    private data class QuranRead(
        val label: String,
        val server: String,
        val surahIds: Set<Int>
    )

    private data class Surah(val id: Int, val name: String)
    private data class RadioStation(val name: String, val url: String)

    private val executor = Executors.newFixedThreadPool(3)
    private val reads = mutableListOf<QuranRead>()
    private val surahs = mutableListOf<Surah>()
    private val radios = mutableListOf<RadioStation>()

    private lateinit var readSpinner: Spinner
    private lateinit var surahSpinner: Spinner
    private lateinit var radioSpinner: Spinner
    private lateinit var statusText: TextView
    private lateinit var playButton: Button

    private var player: MediaPlayer? = null
    private var playerPrepared = false
    private var currentTitle = ""
    private var currentIsRadio = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(11, 25, 21)
        window.navigationBarColor = Color.rgb(11, 25, 21)
        buildUi()
        loadCatalogs()
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply {
            setBackgroundColor(Color.rgb(11, 25, 21))
            isFillViewport = true
        }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(22), dp(18), dp(28))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        scroll.addView(page)
        setContentView(scroll)

        val title = TextView(this).apply {
            text = "مصر قرآن كريم"
            textSize = 30f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            gravity = Gravity.CENTER
        }
        page.addView(title, matchWrap())

        val subtitle = TextView(this).apply {
            text = "تلاوات قرآنية • إذاعات مباشرة • تحميل للاستماع لاحقًا"
            textSize = 14f
            setTextColor(Color.rgb(190, 211, 200))
            gravity = Gravity.CENTER
            setPadding(0, dp(6), 0, dp(18))
        }
        page.addView(subtitle, matchWrap())

        val quranCard = makeCard()
        quranCard.addView(sectionTitle("استمع إلى القرآن"))
        quranCard.addView(fieldLabel("القارئ والرواية"))
        readSpinner = makeSpinner()
        readSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                updateSurahOptions()
            }
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
        }
        quranCard.addView(readSpinner, matchWrap())
        quranCard.addView(fieldLabel("السورة"))
        surahSpinner = makeSpinner()
        quranCard.addView(surahSpinner, matchWrap())

        playButton = makeButton("▶ تشغيل التلاوة")
        playButton.setOnClickListener { togglePlayback(isRadio = false) }
        quranCard.addView(playButton, matchWrap())

        val downloadButton = makeButton("⬇ تحميل السورة")
        downloadButton.setOnClickListener { downloadSelectedSurah() }
        quranCard.addView(downloadButton, matchWrap())
        page.addView(quranCard, cardParams())

        val radioCard = makeCard()
        radioCard.addView(sectionTitle("إذاعات القرآن"))
        radioCard.addView(fieldLabel("اختر إذاعة"))
        radioSpinner = makeSpinner()
        radioCard.addView(radioSpinner, matchWrap())
        val radioButton = makeButton("◉ تشغيل الإذاعة")
        radioButton.setOnClickListener { togglePlayback(isRadio = true) }
        radioCard.addView(radioButton, matchWrap())
        page.addView(radioCard, cardParams())

        val statusCard = makeCard()
        statusCard.addView(sectionTitle("حالة التطبيق"))
        statusText = TextView(this).apply {
            text = "جارٍ تحميل قائمة القراء والسور والإذاعات..."
            textSize = 14f
            setTextColor(Color.rgb(222, 234, 227))
            gravity = Gravity.CENTER
            setPadding(dp(4), dp(8), dp(4), dp(8))
        }
        statusCard.addView(statusText, matchWrap())
        page.addView(statusCard, cardParams())

        val footer = TextView(this).apply {
            text = "يعتمد التطبيق على فهرس MP3Quran.net؛ قد تتغير بعض روابط الصوت أو تتوقف مؤقتًا."
            textSize = 12f
            setTextColor(Color.rgb(145, 167, 155))
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(8), dp(8), 0)
        }
        page.addView(footer, matchWrap())
    }

    private fun loadCatalogs() {
        executor.execute {
            try {
                val json = fetchJson("https://www.mp3quran.net/api/v3/reciters?language=ar")
                val arr = json.optJSONArray("reciters") ?: throw IllegalStateException("قائمة القراء غير متاحة")
                val loaded = mutableListOf<QuranRead>()
                for (i in 0 until arr.length()) {
                    val reciter = arr.optJSONObject(i) ?: continue
                    val reciterName = reciter.optString("name", "قارئ")
                    val moshaf = reciter.optJSONArray("moshaf") ?: continue
                    for (j in 0 until moshaf.length()) {
                        val read = moshaf.optJSONObject(j) ?: continue
                        val server = read.optString("server", "")
                        if (server.isBlank()) continue
                        val ids = read.optString("surah_list", "")
                            .split(",")
                            .mapNotNull { it.trim().toIntOrNull() }
                            .toSet()
                        val readName = read.optString("name", "رواية")
                        loaded.add(QuranRead("$reciterName — $readName", server, ids))
                    }
                }
                runOnUiThread {
                    reads.clear()
                    reads.addAll(loaded)
                    setSpinnerItems(readSpinner, reads.map { it.label })
                    val preferred = reads.indexOfFirst { it.label.contains("عبد الباسط") }
                    if (preferred >= 0) readSpinner.setSelection(preferred)
                    updateSurahOptions()
                    updateStatus("تم تحميل ${reads.size} رواية. اختر القارئ والسورة.")
                }
            } catch (e: Exception) {
                runOnUiThread { updateStatus("تعذر تحميل القراء. تأكد من الإنترنت ثم أعد فتح التطبيق.") }
            }
        }

        executor.execute {
            try {
                val json = fetchJson("https://www.mp3quran.net/api/v3/suwar?language=ar")
                val arr = json.optJSONArray("suwar") ?: throw IllegalStateException("قائمة السور غير متاحة")
                val loaded = mutableListOf<Surah>()
                for (i in 0 until arr.length()) {
                    val item = arr.optJSONObject(i) ?: continue
                    val id = item.optInt("id", 0)
                    val name = item.optString("name", "")
                    if (id in 1..114 && name.isNotBlank()) loaded.add(Surah(id, name.trim()))
                }
                runOnUiThread {
                    surahs.clear()
                    surahs.addAll(loaded)
                    updateSurahOptions()
                }
            } catch (_: Exception) {
                runOnUiThread { updateStatus("تعذر تحميل أسماء السور. افحص اتصال الإنترنت.") }
            }
        }

        executor.execute {
            try {
                val json = fetchJson("https://www.mp3quran.net/api/v3/radios?language=ar")
                val arr = json.optJSONArray("radios") ?: throw IllegalStateException("قائمة الإذاعات غير متاحة")
                val loaded = mutableListOf<RadioStation>()
                for (i in 0 until arr.length()) {
                    val item = arr.optJSONObject(i) ?: continue
                    val name = item.optString("name", "")
                    val url = item.optString("url", "")
                    if (name.isNotBlank() && url.startsWith("http")) loaded.add(RadioStation(name, url))
                }
                runOnUiThread {
                    radios.clear()
                    radios.addAll(loaded)
                    setSpinnerItems(radioSpinner, radios.map { it.name })
                    if (radios.isEmpty()) updateStatus("قائمة الإذاعات فارغة حاليًا.")
                }
            } catch (_: Exception) {
                runOnUiThread { updateStatus("تعذر تحميل الإذاعات؛ يمكنك تجربة مكتبة التلاوات.") }
            }
        }
    }

    private fun updateSurahOptions() {
        if (!::surahSpinner.isInitialized) return
        val selectedRead = reads.getOrNull(readSpinner.selectedItemPosition)
        val available = if (selectedRead == null || selectedRead.surahIds.isEmpty()) {
            surahs
        } else {
            surahs.filter { selectedRead.surahIds.contains(it.id) }
        }
        setSpinnerItems(surahSpinner, available.map { "${it.id}. ${it.name}" })
    }

    private fun togglePlayback(isRadio: Boolean) {
        try {
            val active = player
            if (active != null && playerPrepared && currentIsRadio == isRadio) {
                if (active.isPlaying) {
                    active.pause()
                    playButton.text = "▶ استئناف"
                    updateStatus("تم إيقاف الصوت مؤقتًا.")
                } else {
                    active.start()
                    playButton.text = "Ⅱ إيقاف مؤقت"
                    updateStatus("يعمل الآن: $currentTitle")
                }
                return
            }

            if (isRadio) {
                val station = radios.getOrNull(radioSpinner.selectedItemPosition)
                if (station == null) {
                    updateStatus("انتظر حتى تنتهي قائمة الإذاعات من التحميل.")
                    return
                }
                playUrl(station.url, station.name, isRadio = true)
            } else {
                val read = reads.getOrNull(readSpinner.selectedItemPosition)
                val shown = surahSpinner.selectedItem?.toString().orEmpty()
                val supportedIds = read?.surahIds.orEmpty()
                val surah = surahs.firstOrNull { shown.startsWith("${it.id}. ") && (supportedIds.isEmpty() || supportedIds.contains(it.id)) }
                if (read == null || surah == null) {
                    updateStatus("انتظر حتى تنتهي قائمة القراء والسور من التحميل.")
                    return
                }
                playUrl(audioUrl(read, surah), "${surah.name} — ${read.label}", isRadio = false)
            }
        } catch (_: Exception) {
            updateStatus("تعذر تشغيل الصوت. جرّب رابطًا آخر أو افحص الإنترنت.")
        }
    }

    private fun playUrl(url: String, title: String, isRadio: Boolean) {
        releasePlayer()
        currentTitle = title
        currentIsRadio = isRadio
        playerPrepared = false
        playButton.text = "جارٍ التحميل..."
        updateStatus("جارٍ الاتصال: $title")
        val newPlayer = MediaPlayer()
        player = newPlayer
        newPlayer.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build()
        )
        newPlayer.setOnPreparedListener {
            playerPrepared = true
            it.start()
            playButton.text = "Ⅱ إيقاف مؤقت"
            updateStatus("يعمل الآن: $title")
        }
        newPlayer.setOnCompletionListener {
            playerPrepared = false
            playButton.text = "▶ تشغيل التلاوة"
            updateStatus("انتهى التشغيل.")
        }
        newPlayer.setOnErrorListener { _, _, _ ->
            playerPrepared = false
            playButton.text = "▶ تشغيل التلاوة"
            updateStatus("فشل تشغيل الرابط. قد تكون الإذاعة أو التلاوة غير متاحة حاليًا.")
            true
        }
        try {
            newPlayer.setDataSource(url)
            newPlayer.prepareAsync()
        } catch (_: Exception) {
            releasePlayer()
            playButton.text = "▶ تشغيل التلاوة"
            updateStatus("تعذر فتح رابط الصوت.")
        }
    }

    private fun downloadSelectedSurah() {
        val read = reads.getOrNull(readSpinner.selectedItemPosition)
        val shown = surahSpinner.selectedItem?.toString().orEmpty()
        val supportedIds = read?.surahIds.orEmpty()
        val surah = surahs.firstOrNull { shown.startsWith("${it.id}. ") && (supportedIds.isEmpty() || supportedIds.contains(it.id)) }
        if (read == null || surah == null) {
            updateStatus("اختر القارئ والسورة بعد تحميل القائمة.")
            return
        }
        try {
            val safeName = "${surah.id.toString().padStart(3, '0')}-${surah.name.replace("/", "-")}-${read.label.substringBefore(" — ").replace("/", "-")}.mp3"
            val request = DownloadManager.Request(Uri.parse(audioUrl(read, surah))).apply {
                setTitle("${surah.name} — ${read.label.substringBefore(" — ")}")
                setDescription("تحميل تلاوة قرآنية")
                setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                setMimeType("audio/mpeg")
                setAllowedOverMetered(true)
                setAllowedOverRoaming(false)
                setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, safeName)
            }
            val manager = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            manager.enqueue(request)
            updateStatus("بدأ التحميل. ستجد الملف في مجلد Downloads بعد اكتماله.")
        } catch (_: Exception) {
            updateStatus("تعذر بدء التحميل. تحقق من مساحة الهاتف واتصال الإنترنت.")
        }
    }

    private fun audioUrl(read: QuranRead, surah: Surah): String {
        val base = if (read.server.endsWith("/")) read.server else "${read.server}/"
        return base + String.format(Locale.US, "%03d.mp3", surah.id)
    }

    private fun fetchJson(address: String): JSONObject {
        val connection = (URL(address).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 15000
            readTimeout = 20000
            setRequestProperty("Accept", "application/json")
            setRequestProperty("User-Agent", "MasrQuranKareem/1.0")
        }
        try {
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val body = stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            if (code !in 200..299) throw IllegalStateException("HTTP $code")
            return JSONObject(body)
        } finally {
            connection.disconnect()
        }
    }

    private fun setSpinnerItems(spinner: Spinner, items: List<String>) {
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, items).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
        spinner.adapter = adapter
    }

    private fun makeSpinner(): Spinner = Spinner(this).apply {
        setPadding(dp(8), dp(4), dp(8), dp(4))
        background = rounded(Color.rgb(244, 247, 245), dp(10))
        layoutDirection = View.LAYOUT_DIRECTION_RTL
    }

    private fun makeCard(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        layoutDirection = View.LAYOUT_DIRECTION_RTL
        setPadding(dp(16), dp(16), dp(16), dp(16))
        background = rounded(Color.rgb(25, 48, 40), dp(18))
    }

    private fun sectionTitle(text: String) = TextView(this).apply {
        this.text = text
        textSize = 20f
        setTextColor(Color.WHITE)
        typeface = Typeface.create("sans-serif", Typeface.BOLD)
        gravity = Gravity.RIGHT
        setPadding(0, 0, 0, dp(12))
    }

    private fun fieldLabel(text: String) = TextView(this).apply {
        this.text = text
        textSize = 14f
        setTextColor(Color.rgb(211, 227, 218))
        gravity = Gravity.RIGHT
        setPadding(0, dp(8), 0, dp(6))
    }

    private fun makeButton(text: String): Button = Button(this).apply {
        this.text = text
        textSize = 15f
        isAllCaps = false
        setTextColor(Color.rgb(12, 29, 23))
        background = rounded(Color.rgb(195, 163, 91), dp(12))
        setPadding(dp(12), dp(8), dp(12), dp(8))
        layoutDirection = View.LAYOUT_DIRECTION_RTL
        val params = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        params.topMargin = dp(10)
        layoutParams = params
    }

    private fun rounded(color: Int, radius: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius.toFloat()
        }

    private fun updateStatus(message: String) {
        if (::statusText.isInitialized) statusText.text = message
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun cardParams() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply {
        bottomMargin = dp(14)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun releasePlayer() {
        try {
            player?.setOnPreparedListener(null)
            player?.setOnCompletionListener(null)
            player?.setOnErrorListener(null)
            player?.stop()
            player?.release()
        } catch (_: Exception) {
        }
        player = null
        playerPrepared = false
    }

    override fun onDestroy() {
        releasePlayer()
        executor.shutdownNow()
        super.onDestroy()
    }
}
